%NUMCOL Number of Column
% Returns the number of column of a matrix, vector or any container. 

function c = numcol(obj)
c = size(obj,2) ;
end

% bouh \o/