function ddym2(ab)

fprintf('simulation_ddym call ! my name is %s', ab.name) ;

end