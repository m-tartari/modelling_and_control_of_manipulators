function Q = inter_arti_d5(u)

global ListePoints_cart tf_cart

pi = ListePoints_cart(1,:);
pf = ListePoints_cart(2,:);
D = pf-pi;

% find qc qcd

if (u<tf_cart)
    r = 10*(u/tf_cart)^3 - 15*(u/tf_cart)^4 +6* (u/tf_cart)^5;
    q_d = pi + r*D;
    qd_d = ((30*u^2)/tf_cart^3 - (60*u^3)/tf_cart^4 + (30*u^4)/tf_cart^5)*D;
    qdd_d = D*((120*u^3)/tf_cart^5 - (180*u^2)/tf_cart^4 + (60*u)/tf_cart^3);
else
   q_d=pf;
   qd_d=zeros(size(q_d));
   qdd_d=zeros(size(q_d));
end

Q = [q_d, qd_d, qdd_d];


