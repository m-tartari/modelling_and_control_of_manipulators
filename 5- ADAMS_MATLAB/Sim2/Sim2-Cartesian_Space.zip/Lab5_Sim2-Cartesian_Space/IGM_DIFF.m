function qd = IGM_DIFF(Xd)
global q_prev
lamda=1; %damping
epsilon= 0.1; %error margin

% i� Initialize the first counter k = 0 
for k=0:1:500           % (this counter will give the number of trials for 
                        %  the initial joint configuration).

    % iii- pick up a not-so-random value for qc using the Matlab function rand1. 
    if q_prev==zeros(length(q_prev),1)
        qc=ones(length(q_prev),1)*0.01;
    else
        qc=q_prev;
    end
    %size(qc)
    
    for m=0:1:1000      %(this counter gives the number of iterations which 
                        %   have been intialized by this joint configuration).
                        
    % iv� Calculate the Cartesian coordinates Xc using the DGM of the Kuka
    Xc=DGM(qc)';
    % v- Calculate the difference dX between the desired Xd and the current Xc
    dX=Xd-Xc
    
    % If max(abs(dX)) < ? , put qd = qc, if the joint angles are within the
    % joint domains. Put err = 0 and stop the programme.
    if max(abs(dX))<epsilon
         break;
    end
    
    %MDH Table
    sigma=zeros(1,7);
    alpha=[0 pi/2 -pi/2 -pi/2 -pi/2 pi/2 -pi/2];
    d=sigma;
    theta=qc';
    r=[0 0 0.4 0 0.39 0 0];
    
    % viii- Update the value of qc as follows:
    % � Calculate the Jacobian matrix J = JKuka(qc);
    % � calculate dq corresponding to dX using the pseudo-inverse;
    % � qc = qc + dq
    J=Genjac(sigma,alpha,d,theta,r,qc);
    dq=(J')*inv(J*J')*dX;
    qc=qc+dq*lamda;
    end
   
    % vi- m = m + 1, if m = 1000 goto error.
    if m==1000
        error('m=1000');
    else
        break;
    end
end

% ii- k = k + 1, if k = 500, put err = 1 and stop the programme.
if  k==500
    error('k=500');
end

qd=qc;

