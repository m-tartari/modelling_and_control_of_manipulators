function out = simulate_ddym(ab, in)
%SIMULATE_DDYM Summary of this function goes here
%   Detailed explanation goes here

out = 0 ;

end

