%NUMROW Number of Rows
% Returns the number of rows of a matrix, vector or any container OBJ. 

function c = numrow(obj)
c = size(obj,1) ;
end