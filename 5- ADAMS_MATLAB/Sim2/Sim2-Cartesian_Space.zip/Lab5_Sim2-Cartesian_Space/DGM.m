function P=DGM(q)
% Direct Geometrical Model of Kuka LWR.

C1=cos(q(1));
S1=sin(q(1));
C2=cos(q(2));
S2=sin(q(2));
C3=cos(q(3));
S3=sin(q(3));
C4=cos(q(4));
S4=sin(q(4));
C5=cos(q(5));
S5=sin(q(5));
C6=cos(q(6));
S6=sin(q(6));
C7=cos(q(7));
S7=sin(q(7));
C45=cos(q(4) + q(5));
S45=sin(q(4) + q(5));

s = [	C7*(C6*(C1*S2*S45 + C45*(C1*C2*C3 - S1*S3)) + S6*(-C1*C2*S3 - C3*S1)) + S7*(C1*C45*S2 - S45*(C1*C2*C3 - S1*S3)) ;
	C7*(C6*(C45*(C1*S3 + C2*C3*S1) + S1*S2*S45) + S6*(C1*C3 - C2*S1*S3)) + S7*(C45*S1*S2 - S45*(C1*S3 + C2*C3*S1)) ;
	C7*(C6*(-C2*S45 + C3*C45*S2) - S2*S3*S6) + S7*(-C2*C45 - C3*S2*S45) ;
	0];
n = [	C7*(C1*C45*S2 - S45*(C1*C2*C3 - S1*S3)) - S7*(C6*(C1*S2*S45 + C45*(C1*C2*C3 - S1*S3)) + S6*(-C1*C2*S3 - C3*S1)) ;
	C7*(C45*S1*S2 - S45*(C1*S3 + C2*C3*S1)) - S7*(C6*(C45*(C1*S3 + C2*C3*S1) + S1*S2*S45) + S6*(C1*C3 - C2*S1*S3)) ;
	C7*(-C2*C45 - C3*S2*S45) - S7*(C6*(-C2*S45 + C3*C45*S2) - S2*S3*S6) ;
	0];
a = [	C6*(-C1*C2*S3 - C3*S1) - S6*(C1*S2*S45 + C45*(C1*C2*C3 - S1*S3)) ;
	C6*(C1*C3 - C2*S1*S3) - S6*(C45*(C1*S3 + C2*C3*S1) + S1*S2*S45) ;
	-C6*S2*S3 - S6*(-C2*S45 + C3*C45*S2) ;
	0];
p = [	-0.39*C1*C2*S3 - 0.4*C1*S2 - 0.39*C3*S1;
	0.39*C1*C3 - 0.39*C2*S1*S3 - 0.4*S1*S2;
	0.4*C2 - 0.39*S2*S3;
	1];

P_x = p(1);
P_y = p(2);
P_z = p(3);
Theta_1 = atan2(-a(2),a(3));
Theta_2 = atan2(-a(1),-a(2)*sin(Theta_1) + a(3)*cos(Theta_1))	;
Theta_3 = atan2(a(2)*cos(Theta_1) + n(2)*sin(Theta_1), n(2)*cos(Theta_1) + n(3)*sin(Theta_1));

P=[P_x,P_y,P_x,Theta_1,Theta_2,Theta_3]