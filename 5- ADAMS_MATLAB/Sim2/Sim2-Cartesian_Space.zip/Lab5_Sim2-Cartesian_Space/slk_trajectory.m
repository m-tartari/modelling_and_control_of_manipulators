function OUT = slk_trajectory(t)

global traj 

[p, v, a] = traj.update(t) ;

OUT = [p; v; a] ;

end
