clc;
clear b p560
b(1) = mBody(0,[  0     0       0   0     ]);
b(2) = mBody(1,[ -pi/2  0       0   .2435 ]);
b(3) = mBody(2,[  0     .4318   0  -.0934 ]);
b(4) = mBody(3,[  pi/2  -.0203  0   .4331 ]);
b(5) = mBody(4,[ -pi/2  0       0   0     ]);
b(6) = mBody(5,[  pi/2  0       0   0     ]);

p560 = mArticulatedBody(b, 'name', 'Puma 560');

qd = 2*pi*rand(p560.n,1) 
Td = p560.T(0,p560.n,qd)
qo = p560.igm(Td) 
% To = p560.T(0,p560.n,qo)
% Td-To

%%
clear all
clear b p560
b(1) = mBody(0,[  0     0       0   0     ]);
b(2) = mBody(1,[ -pi/2  0       0   .2435 ]);
b(3) = mBody(2,[  0     .4318   0  -.0934 ]);
b(4) = mBody(3,[  pi/2  -.0203  0   .4331 ]);
b(5) = mBody(4,[ -pi/2  0       0   0     ]);
b(6) = mBody(5,[  pi/2  0       0   0     ]);

p560 = mArticulatedBody(b, 'name', 'Puma 560');

Td=[0.6957    0.7164    0.0522    0.3068;
    0.3500   -0.4015    0.8463   -0.3328;
    0.6273   -0.5705   -0.5301    0.6690;
         0         0         0    1]
qo = p560.igm(Td)