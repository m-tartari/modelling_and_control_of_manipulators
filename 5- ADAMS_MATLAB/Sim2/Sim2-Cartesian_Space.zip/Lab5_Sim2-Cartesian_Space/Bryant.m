function Td=Bryant(u)
% Obtain T_d using bryant angles
C1= cos(u(4));     C2= cos(u(5));     C3= cos(u(6));
S1= sin(u(4));     S2= sin(u(5));     S3= sin(u(6));

Td=	[   	    C2*C3,  		   -C2*S3,	    S2,	     u(1);
	 S1*S2*C3 + C1*S3,	-S1*S2*S3 + C1*C3,	-S1*C2,	     u(2);
	-C1*S2*C3 + S1*S3,	 C1*S2*S3 + S1*C3,	 C1*C2,	     u(3);
                    0,                  0,	     0,        1];