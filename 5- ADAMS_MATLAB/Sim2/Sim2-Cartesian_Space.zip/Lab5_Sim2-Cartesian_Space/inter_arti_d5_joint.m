function Q = inter_arti_d5_joint(u)

global ListePoints_joint tf_joint

pi = ListePoints_joint(1,:);
pf = ListePoints_joint(2,:);
D = pf-pi;

% find qc qcd

if (u<tf_joint)
    r = 10*(u/tf_joint)^3 - 15*(u/tf_joint)^4 +6* (u/tf_joint)^5;
    q_d = pi + r*D;
    qd_d = ((30*u^2)/tf_joint^3 - (60*u^3)/tf_joint^4 + (30*u^4)/tf_joint^5)*D;
    qdd_d = D*((120*u^3)/tf_joint^5 - (180*u^2)/tf_joint^4 + (60*u)/tf_joint^3);
else
   q_d=pf;
   qd_d=zeros(size(q_d));
   qdd_d=zeros(size(q_d));
end

Q = [q_d, qd_d, qdd_d];


