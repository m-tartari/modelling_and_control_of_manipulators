function P=Solve_Bryant(T)
% T=[s,n,a,p];
s=T(:,1);
n=T(:,2);
a=T(:,3);
p=T(:,4);

P_x = p(1);
P_y = p(2);
P_z = p(3);
Theta_1 = atan2(-a(2),a(3));
Theta_2 = atan2(-a(1),-a(2)*sin(Theta_1) + a(3)*cos(Theta_1))	;
Theta_3 = atan2(a(2)*cos(Theta_1) + n(2)*sin(Theta_1), n(2)*cos(Theta_1) + n(3)*sin(Theta_1));

P=[P_x,P_y,P_x,Theta_1,Theta_2,Theta_3];