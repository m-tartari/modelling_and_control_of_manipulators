function Q = inter_arti_d5_cart(u)
% copyright Michele Tartari, Iker Landa
global ListePoints_cart tf_cart

pi = ListePoints_cart(1,:);
pf = ListePoints_cart(2,:);
D = pf-pi;

% find qc qcd

if (u<tf_cart)
    r = 10*(u/tf_cart)^3 - 15*(u/tf_cart)^4 +6* (u/tf_cart)^5;
    pc= pi + r*D;
    pcd = ((30*u^2)/tf_cart^3 - (60*u^3)/tf_cart^4 + (30*u^4)/tf_cart^5)*D;
    pcdd = D*((120*u^3)/tf_cart^5 - (180*u^2)/tf_cart^4 + (60*u)/tf_cart^3);
else
    pc=pf;
    pcd=zeros(size(pc));
end

Q = pc'

