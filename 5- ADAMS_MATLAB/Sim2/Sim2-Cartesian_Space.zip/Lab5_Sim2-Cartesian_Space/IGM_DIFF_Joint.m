function qd = IGM_DIFF_Joint(u)
global robot
qc=u(1:7); %useonly position
q_prev=u(22:28);

% For unknown reasons this code works
% Tj = robot.T(0,robot.n,qc);       %   we obtain Xd from toolbox method
% Xd = Solve_Bryant(Tj);
% Td = Bryant(Xd);
% q_prev
% qo = robot.igm(Td,'init', q_prev);

% For unknown reasons this code does not work
% Tj = robot.T(0,robot.n,qc);     %   we obtain Xd from toolbox method
% Xd = SolveBryant(Tj);
% Td = Bryant(Xd);
% if Td == Tj
%     clear Tj
%     qo = robot.igm(Td,'init', q_prev);
% else
%     error('Td!=Tj');
% end

% this code doen't work either
Xd=DGM(qc);
Td = Bryant(Xd);
qo = robot.igm(Td,'init', q_prev);

% From this, we can notice that he toolbox method robot.igm does not work if 
%    T is not computed using robot.T, which means we cannot give a trajectory 
%   computed from a cartesian trajectory generator since robot.T only works
%   for input joint positions.

% replace qc=NaN with qd=q_prev to prevent crashes
if isnan(qo)
    qd=q_prev;
else
    qd=qo;
end

